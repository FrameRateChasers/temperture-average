﻿Public Class Form1
    'JEFFREY HAGAN
    'TEMPERTURE AVERAGE
    'VB FOR BUSINESS

    'declared golbal varibles
    Dim intTotalAvg, intTempInput1, intTempInput2, intTempInput3, intTempInput4, intTempInput5 As Integer
    'global varible for division
    Dim int5 As Integer = 5



    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears text
        txt1.Text = ""
        txt2.Text = ""
        txt3.Text = ""
        txt4.Text = ""
        txt5.Text = ""
        lblAverageResult.Text = ""
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'try catch makes sure you enter numbers only
        Try
            'convertes the input from textbox and stores the results in Global varible intTempInput1-5
            intTempInput1 = CInt(txt1.Text)
            intTempInput2 = CInt(txt2.Text)
            intTempInput3 = CInt(txt3.Text)
            intTempInput4 = CInt(txt4.Text)
            intTempInput5 = CInt(txt5.Text)

            'adds each temp and stores it into intTotalAvg
            intTotalAvg = (intTempInput1 + intTempInput2 + intTempInput3 + intTempInput4 + intTempInput5)

            'divides the total of temperture by 5
            lblAverageResult.Text = CStr(intTotalAvg / int5)

        Catch
            MsgBox("please enter whole number please", MsgBoxStyle.OkOnly)
        End Try

    End Sub
End Class
